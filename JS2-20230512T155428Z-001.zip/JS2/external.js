function sayHi() {
   alert('Hi external!'); 
}