function tim(employeeName, startedWithTheCompany, salaryPerMonth, permanent){
    var tim = 
        `Employee name: ${employeeName} \nStarted with the company: ${startedWithTheCompany} \nSalary per month: £${salaryPerMonth} \nPermanent: ${permanent}`
    
    alert(tim); 
}
